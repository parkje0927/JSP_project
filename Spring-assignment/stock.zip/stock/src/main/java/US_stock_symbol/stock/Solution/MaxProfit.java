package US_stock_symbol.stock.Solution;

import org.springframework.web.bind.annotation.*;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@RestController
public class MaxProfit {

    private final MaxProfitService service;

    public MaxProfit(MaxProfitService service) {
        this.service = service;
    }

    //max-profit 처리
    //입력 예시) localhost:8080/stocks/max-profit/AAPL?date=2020-09-19
    @GetMapping("/stocks/max-profit/{symbol}")
    @ResponseBody
    public HashMap<String, String> callAPI(@PathVariable("symbol") String symbol, @RequestParam String date) throws IOException, ParseException {

        //endDate 형
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

        // 종가를 기준으로 하며 시간을 제외하고 년, 월, 일만 받았기 때문에 2020-09-21을 입력할 경우에는 2020-09-20부터 180일 전 데이터를 가져오게 됩니다.
        // 따라서 21일 데이터를 가져와야 한다면 2020-09-22를 입력해야 합니다.

        //endDate 의 unix timestamp
        Date endDate = dateFormat.parse(date); //input
        long endDateTimeStamp = endDate.getTime() / 1000; //1600354800

        //endDate 로부터 180일 전 계산하여 startDate 계산
        Calendar cal = Calendar.getInstance();
        cal.setTime(endDate);
        cal.add(Calendar.DAY_OF_MONTH, -180);
        String tempDate = dateFormat.format(cal.getTime()); //2020-03-22

        Date startDate = dateFormat.parse(tempDate);
        long startDateTimeStamp = startDate.getTime() / 1000; //1584802800

        String url = "https://query1.finance.yahoo.com/v7/finance/download/"
                    + symbol + "?period1=" + startDateTimeStamp + "&period2=" + endDateTimeStamp
                    + "&interval=1d&events=history";

        URL rowdata = new URL(url);
        URLConnection data = rowdata.openConnection();
        Scanner input = new Scanner(data.getInputStream());
        if (input.hasNext()) {
            input.nextLine();
        }

        //close 가격을 기준으로 profit 계산함

        // closePrice => Map구조로, 날짜와 종가 가격을 넣었습니다.
        // stockPrice => ArrayList구조로 가격만 double 형태로 넣었습니다.
        // getMaxProfitDate => Map구조로, index순서와 날짜를 넣었습니다. 나중에 날짜를 꺼내오기 위함입니다.

        HashMap<String, String> closePrice = new HashMap<>();
        ArrayList<Double> stockPrice = new ArrayList<>();
        HashMap<Integer, String> getMaxProfitDate = new HashMap<>();
        int index = 0;

        while (input.hasNextLine()) {
            String line = input.nextLine();
            String temp[] = line.split(",");

            closePrice.put(temp[0], temp[4]); //Date, Open, High, Low, Close, Adj Close, Volume 순서로 저장되어있습니다.

            double tempPrice = Double.parseDouble(temp[4]);
            stockPrice.add(tempPrice);

            getMaxProfitDate.put(index++, temp[0]); //날짜를 가져오기 위해 key 값으로 index만 증가시켜서 넣었습니다.
        }

        return service.GetMaxProfit(stockPrice, getMaxProfitDate);
    }
}
