package US_stock_symbol.stock.Solution;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;

@Service
public class MaxProfitService {

    private static HashMap<String, String> result = new HashMap<>();

    public HashMap <String, String> GetMaxProfit(ArrayList<Double> stockPrice, HashMap<Integer, String> getMaxProfitDate) {

        int length = stockPrice.size();
        double maxProfit = 0.0;
        int buy_date = 0;
        int sell_date = 0;

        if (length > 0) {
            for (int i = 0; i < length - 1; i++) {
                for (int j = i + 1; j < length; j++) {
                    if (stockPrice.get(j) - stockPrice.get(i) > maxProfit) {
                        maxProfit = stockPrice.get(j) - stockPrice.get(i);
                        buy_date = i;
                        sell_date = j;
                    }
                }
            }
        }

        String tempProfit = Double.toString(maxProfit);
        result.put("max-profit" , tempProfit);
        result.put("buy-date" , getMaxProfitDate.get(buy_date));
        result.put("sell-date" , getMaxProfitDate.get(sell_date));

        return result;
    }

}
