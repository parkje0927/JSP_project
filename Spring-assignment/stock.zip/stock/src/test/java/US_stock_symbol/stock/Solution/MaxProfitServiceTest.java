package US_stock_symbol.stock.Solution;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

class MaxProfitServiceTest {

    @Test
    void getMaxProfit() {

        //given
        int price1[] = {7, 1, 5, 3, 6, 4}; //expected = 5 (1일 때 사서 6일 때 파는 것이 최대 이익입니다.)
        int price2[] = {7, 6, 4, 3, 1}; // expected = 0 (가격이 계속 떨어지기 때문에 거래가 이루어지지 않아서 결과는 0 입니다.)
        double maxProfit = 0.0;
        int buy_date = 0;
        int sell_date = 0;

        //when
        int length = price1.length;
        if (length > 0) {
            for (int i=0;i<length-1;i++) {
                for (int j=i+1;j<length;j++) {
                    if (price1[j] - price1[i] > maxProfit) {
                        maxProfit = price1[j] - price1[i];
                        buy_date = i;
                        sell_date = j;
                    }
                }
            }
        }

        //then
        Assertions.assertThat(maxProfit).isEqualTo(5);

        //when
        length = price2.length;
        maxProfit = 0.0;
        if (length > 0) {
            for (int i=0;i<length-1;i++) {
                for (int j=i+1;j<length;j++) {
                    if (price2[j] - price2[i] > maxProfit) {
                        maxProfit = price2[j] - price2[i];
                        buy_date = i;
                        sell_date = j;
                    }
                }
            }
        }

        //then
        Assertions.assertThat(maxProfit).isEqualTo(0);

    }
}