<h2> 뱅크샐러드_박정현 </h2>



<h4> Prerequisite </h4>

- java 버전 : 11
- 빌드 도구 : gradle

<h4> 빌드하는 방법 (Mac) </h4>

- cd 폴더 위치
- ./gradlew build (permission denied 시 chmod +x gradlew 실행 후 다시 입력합니다.)


<h4> 런 하는 방법 </h4>

- cd build/libs
- ls -arlth 시 나오는 jar 파일을, java -jar 뒤에 붙여서 실행합니다.

<h4> Method </h4>

- GET

<h4> URL Params 및 예시 </h4>

- Required

	- PathVariable : 확인하고 싶은 StockSymbol (예시 - APPL, GOOG)
	- RequestParam : date = yyyy-MM-dd
	- 예시 : stocks/max-profit/GOOG?date=2020-09-19

<h4> Success Reponse </h4>

- Code : 200

<h4> Sample Call </h4>

- localhost:8080/stocks/max-profit/GOOG?date=2020-09-19

<h4> Notes </h4>

- StockPrice 데이터에는 Date, Open, High, Low, Close, Adj Close, Volume에 대한 값이 순서대로 들어가 있으며, 저는 여기서 Close인 종가 가격을 기준으로 값을 처리했습니다. 따라서 split을 했을 때 배열의 순서에 따라 1번째 위치에 있는 Date와 4번째 위치에 있는 Close 가격 값만 temp에 넣어서 처리했습니다.

- 또한 종가를 기준으로 하며 시간을 제외하고 년, 월, 일만 받았기 때문에 2020-09-21을 입력할 경우에는 2020-09-20부터 180일 전 데이터를 가져오게 됩니다. 따라서 21일 데이터를 가져와야 한다면 2020-09-22를 입력해야 합니다.

- URL에는 timeStamp 형식으로 들어가야 하므로 yyyy-MM-dd 형식의 String 값을 timeStamp 형식으로 바꿔서 처리했습니다.

- MaxProfit을 계산하는 알고리즘은 MaxProfitService 클래스에 만들고 HashMap 구조로 반환을 하도록 하여 JSON형식으로 결과를 보여줍니다.


<h4> documentation </h4>

- APPL symbol 예시 

	- https://query1.finance.yahoo.com/v7/finance/download/AAPL?period1=1568813640&period2=1600436040&interval=1d&events=history;


 